﻿function AlertMeFromOtherFile()
{
    return "The other script file has been loaded.";
}