﻿function SometOtherFunction() {
     alert("Good one!");
}